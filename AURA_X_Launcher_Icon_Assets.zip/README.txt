AURA X launcher icon resources

Copy the contents of this res/ folder into:
app/src/main/res/

If Android Studio/Codespaces asks whether to merge folders, choose merge.
These files provide:
- Adaptive icon for Android 8.0+
- Density-specific legacy launcher icons
- Dark obsidian background with transparent glass artwork foreground

Then ensure app/src/main/AndroidManifest.xml uses:
android:icon="@mipmap/ic_launcher"
android:roundIcon="@mipmap/ic_launcher"

Do not replace your existing strings.xml or other project files.
